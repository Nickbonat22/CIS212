
public class test {

	public static void main(String[] args) {
		
		OccurrenceSet<Integer> intSet = new OccurrenceSet<Integer>();
		
		intSet.add(1);
		intSet.add(5);
		intSet.add(5);
		intSet.add(3);
		intSet.add(3);
		intSet.add(3);
		
		System.out.println(intSet);
		
		
		OccurrenceSet<String> stringSet = new OccurrenceSet<String>(); 
		stringSet.add("hello");
		stringSet.add("hello"); 
		stringSet.add("world"); 
		stringSet.add("world"); 
		stringSet.add("world"); 
		stringSet.add("here"); 
		
		System.out.println(stringSet);
		
	}

}
