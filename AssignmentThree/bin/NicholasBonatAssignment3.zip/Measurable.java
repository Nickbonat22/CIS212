
public interface Measurable {
	
	// calculate area
	double getArea();
}
